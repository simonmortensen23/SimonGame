let game = {
    currentGame: [],
    score: 0,
};


module.exports = { game };